- 👋 Hi, I’m @Howard717
- 👀 I’m interested in learning how to code.
- 🌱 I’m currently learning at a snail's pace.
- 💞️ I’m looking to collaborate on any project I can realistically contribute to.
- 📫 How to reach me by email

<!---
Howard717/Howard717 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
